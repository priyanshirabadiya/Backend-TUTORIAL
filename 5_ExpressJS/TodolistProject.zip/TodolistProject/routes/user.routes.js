const express = require('express');
const userRoutes = express.Router();
const Todo = require('../model/todo.model')
const {
    registerUser,
    loginUser,
    todolist,
    userProfile
} = require('../controller/user.controller');

const { verifyToken } = require('../helpers/user.verifyToken')

userRoutes.get('/register', (req, res) => {
    res.render('register', { user: {} }); // Pass an empty user object for rendering
});

userRoutes.get('/login', (req, res) => {
    res.render('login', { user: {} }); // Pass an empty user object for rendering
});

userRoutes.post('/register', registerUser);

userRoutes.post('/login', loginUser);

userRoutes.get('/profile', verifyToken, userProfile);

userRoutes.get('/success', async (req, res) => {
    try {
        const todos = await Todo.find({});
        res.render('success', { todos }); // Pass the todos to the EJS template
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred while fetching todos.');
    }
});

userRoutes.post('/todos', async (req, res) => {
    try {
        await Todo.create(req.body);
        res.redirect('/success'); // Redirect back to the success page after adding the todo
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred while adding a new todo.');
    }
});



// --------------------------------- updatation

// userRoutes.put('/todos', async (req, res) => {
//     const todoupdate = await Todo.findByIdAndUpdate({_id : req.query._id}, { $set: req.body }, { new: true });
//     res.json({todoupdate , message : "updated..." });  
// })


// userRoutes.get('/todos/:id', async (req, res) => {
//     const todos = await Todo.findById(req.params.id);
//     res.json(todos);
// })


// userRoutes.delete('/todos/:id', async (req, res) => {
//     const todo = await Todo.findByIdAndDelete(req.params.id);
//     res.json({todo , message : "Deleted..." });
// })



module.exports = userRoutes;
